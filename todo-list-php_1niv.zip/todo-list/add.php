<?php

//adauga un alt rind in tasks
const PATH="./tasks.txt";
$title=$_GET['title']??'';
var_dump($title);
if(strlen($title)>=3 and strlen($title)<=80){
    file_put_contents(PATH,$title.".\n",FILE_APPEND);
    header("location: index.php");  //redirectioneaza inapoi
}else{
    print "!!!Wrong is need 3 symbols!!!";
}

?>
<form>
    <h2>Add a new tasks</h2>
    <hr>
    <input name="title" type="text" size="80" placeholder="task title...">
    <button>Save</button>


<form>
