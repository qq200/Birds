<?php
////failesystem function --->>>>>PERMISSIONS

//file_exists -daca este
//file_get_contents
//file_put_contents
const PATH="./tasks.txt";

//reads&prints tasks:
function read_print_tasks(){
    if(file_exists(PATH)){
        
        $content=file_get_contents(PATH);
        $lines=explode(".",$content);
        // var_dump($content);
        // var_dump($lines);
        array_pop($lines);
        print "<ol>";
        foreach($lines as $i=>$line){
            print "<li> $line</li>";
        }
        print "<li> <a href='./add.php'>Add new</a></li>";
        print "</ol>";


    }else{
        print "No Data";
    }
}

read_print_tasks();





?>