<?php
if(file_exists("./data.txt")){
    $content=file_get_contents("./data.txt");
    $lines=explode("*",$content);
    array_pop($lines);
    
    foreach($lines as $line){
        $slide=explode("#",$line);
            // var_dump($slide);
        print "
            <div>
                <img src='$slide[0]' width='80'>
                <b>$slide[1]</b>
                <small>$slide[2]</small>
            </div>
        ";
    }
}else{
    print "No file";
}


///acasa: 1) de adaugat data foto 2) de calculat cite zile in urma a fost postata strtodate(),data(),data function
?>

